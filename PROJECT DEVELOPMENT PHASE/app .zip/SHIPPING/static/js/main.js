// script.js

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('predictionForm');
    const resultDiv = document.getElementById('predictionResult');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const formData = new FormData(form);
        
        // Sending form data to the server using fetch
        fetch('/predict', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            // Display prediction result in the result div
            resultDiv.innerHTML = `<p>${data}</p>`;
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});
